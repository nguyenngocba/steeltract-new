export function MachineMonitoring() { return <></> }
