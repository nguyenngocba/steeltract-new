import {
  Injectable,
} from '@nestjs/common'

import { PrismaService }
from '../../../core/database/prisma.service'

@Injectable()
export class InventoryRepository {

  constructor(

    private readonly prisma:
      PrismaService,
  ) {}

  async findAll() {

    try {

      return await this.prisma.inventory.findMany({

        take: 100,

        orderBy: {

          createdAt:
            'desc',
        },
      })

    } catch {

      return []
    }
  }

  async analytics() {

    try {

      const total =
        await this.prisma.inventory.count()

      return {

        total,

        synced:
          true,
      }

    } catch {

      return {

        total: 0,
        synced: false,
      }
    }
  }
}
