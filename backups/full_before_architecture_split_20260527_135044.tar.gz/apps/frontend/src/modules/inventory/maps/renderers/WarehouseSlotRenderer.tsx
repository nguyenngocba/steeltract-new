export function WarehouseSlotRenderer() { return <></> }
