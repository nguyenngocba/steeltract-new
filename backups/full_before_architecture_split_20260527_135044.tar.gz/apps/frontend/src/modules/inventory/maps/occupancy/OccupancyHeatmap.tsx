export function OccupancyHeatmap() { return <></> }
