export function WarehouseRackRenderer() { return <></> }
