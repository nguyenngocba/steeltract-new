import { http }
from '../../../shared/api/http'

export async function getInventoryRuntime() {

  const response = await http.get(
    '/inventory',
  )

  return response.data
}

export async function getInventoryAnalytics() {

  const response = await http.get(
    '/inventory/analytics',
  )

  return response.data
}
