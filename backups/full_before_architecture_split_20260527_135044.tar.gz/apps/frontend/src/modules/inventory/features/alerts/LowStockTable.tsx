export function LowStockTable() { return <></> }
