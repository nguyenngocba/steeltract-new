export function InboundTelemetry() { return <></> }
