export function StockView() { return <></> }
