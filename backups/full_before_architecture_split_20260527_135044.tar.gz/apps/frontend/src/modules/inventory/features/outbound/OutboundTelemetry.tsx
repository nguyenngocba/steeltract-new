export function OutboundTelemetry() { return <></> }
