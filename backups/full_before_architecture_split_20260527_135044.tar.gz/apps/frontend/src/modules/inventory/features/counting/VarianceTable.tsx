export function VarianceTable() { return <></> }
