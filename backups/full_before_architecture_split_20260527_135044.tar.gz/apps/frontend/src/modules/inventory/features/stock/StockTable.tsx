export function StockTable() { return <></> }
