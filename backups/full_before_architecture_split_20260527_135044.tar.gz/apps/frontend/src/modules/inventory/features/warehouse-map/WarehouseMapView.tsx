export function WarehouseMapView() { return <></> }
