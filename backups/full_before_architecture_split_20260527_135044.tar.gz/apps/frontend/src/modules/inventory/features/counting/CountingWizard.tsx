export function CountingWizard() { return <></> }
