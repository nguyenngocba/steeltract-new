export function StockFullscreen() { return <></> }
