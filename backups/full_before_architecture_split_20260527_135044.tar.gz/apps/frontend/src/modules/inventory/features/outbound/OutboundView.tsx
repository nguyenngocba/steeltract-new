export function OutboundView() { return <></> }
