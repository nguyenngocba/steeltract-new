export function CountingView() { return <></> }
