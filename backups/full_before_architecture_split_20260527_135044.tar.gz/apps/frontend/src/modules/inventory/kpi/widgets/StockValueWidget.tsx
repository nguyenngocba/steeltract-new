export function StockValueWidget() { return <></> }
