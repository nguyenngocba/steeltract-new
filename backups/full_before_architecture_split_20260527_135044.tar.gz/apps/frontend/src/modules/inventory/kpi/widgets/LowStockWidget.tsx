export function LowStockWidget() { return <></> }
