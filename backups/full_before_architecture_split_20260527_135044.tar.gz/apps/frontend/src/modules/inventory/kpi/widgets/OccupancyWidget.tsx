export function OccupancyWidget() { return <></> }
