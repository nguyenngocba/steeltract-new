export * from './pages/InventoryPage'
