export function FabricationView() { return <></> }
