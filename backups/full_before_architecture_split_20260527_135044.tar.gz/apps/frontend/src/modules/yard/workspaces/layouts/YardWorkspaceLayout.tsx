export function YardWorkspaceLayout() { return <></> }
