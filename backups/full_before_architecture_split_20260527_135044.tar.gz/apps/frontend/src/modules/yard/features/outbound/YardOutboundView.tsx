export function YardOutboundView() { return <></> }
