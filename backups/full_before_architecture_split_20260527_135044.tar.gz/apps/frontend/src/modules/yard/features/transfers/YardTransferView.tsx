export function YardTransferView() { return <></> }
