export function YardHeatmapView() { return <></> }
