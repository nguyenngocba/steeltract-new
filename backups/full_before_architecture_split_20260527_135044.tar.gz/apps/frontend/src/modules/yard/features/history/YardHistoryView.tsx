export function YardHistoryView() { return <></> }
