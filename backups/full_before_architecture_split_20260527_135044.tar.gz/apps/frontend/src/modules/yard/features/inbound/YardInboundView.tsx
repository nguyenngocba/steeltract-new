export function YardInboundView() { return <></> }
