export function YardTrackingView() { return <></> }
