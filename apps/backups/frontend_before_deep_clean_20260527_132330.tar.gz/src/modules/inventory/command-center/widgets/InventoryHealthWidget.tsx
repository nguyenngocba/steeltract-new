export function InventoryHealthWidget() { return <></> }
