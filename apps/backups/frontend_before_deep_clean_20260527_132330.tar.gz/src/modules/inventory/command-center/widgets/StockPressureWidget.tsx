export function StockPressureWidget() { return <></> }
