export function InboundQueueWidget() { return <></> }
