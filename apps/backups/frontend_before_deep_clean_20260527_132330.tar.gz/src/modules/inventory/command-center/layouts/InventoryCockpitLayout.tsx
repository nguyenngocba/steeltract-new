export function InventoryCockpitLayout() { return <></> }
