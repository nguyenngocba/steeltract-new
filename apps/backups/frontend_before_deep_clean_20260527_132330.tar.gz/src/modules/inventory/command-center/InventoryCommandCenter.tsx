export function InventoryCommandCenter() { return <></> }
